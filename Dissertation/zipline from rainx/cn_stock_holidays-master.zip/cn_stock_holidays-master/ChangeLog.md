1.3 2018年4月17日
* update hk 2018 holiday data

1.2 2017年12月20日
---
* 增加get-day-list命令，用于获取一段周期内的工作日或者休息日列表

1.1 2017年11月27日
---
* merge pr #2 from @JaysonAlbert
* 增加minutes per session 
* 从wind获取假日信息代码 

1.0 2017年11月6日
---
* 增加对香港交易所的支持

0.x 
---
* 史前版本，历史记录还未整理
