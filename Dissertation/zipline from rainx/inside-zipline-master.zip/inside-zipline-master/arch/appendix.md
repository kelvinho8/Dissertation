# 附图

真不该把他们放到一张图上.. 害的我后期还要用gimp切图用在文章里，这里是完整的图  T_T



![附图](../images/zipline_arch.png)

